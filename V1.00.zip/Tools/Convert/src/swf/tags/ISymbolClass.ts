export interface ISymbolClass
{
    id: number;
    name: string;
}
