export interface ISWFTagLabel
{
    frameNum: number;
    frameLabel: string;
}
