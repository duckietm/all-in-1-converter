export interface ISWFTagHeader
{
    code: number;
    length: number;
}
