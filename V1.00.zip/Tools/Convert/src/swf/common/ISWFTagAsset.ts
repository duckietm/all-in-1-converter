export interface ISWFTagAsset
{
    id: number;
    name: string;
}
