export interface ISWFTagSplitter
{
    x: number;
    y: number;
    width: number;
    height: number;
}
