export interface IEffectMapLibrary
{
    id?: string;
    lib?: string;
    type?: string;
    revision?: number;
}
