import { IFigureDataColor } from './IFigureDataColor';

export interface IFigureDataPalette
{
    id?: number;
    colors?: IFigureDataColor[];
}
