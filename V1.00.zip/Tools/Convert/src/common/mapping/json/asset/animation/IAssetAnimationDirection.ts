export interface IAssetAnimationDirection
{
    offset?: number;
}
