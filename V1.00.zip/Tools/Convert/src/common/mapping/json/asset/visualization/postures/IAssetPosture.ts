export interface IAssetPosture
{
    id?: string;
    animationId?: number;
}
