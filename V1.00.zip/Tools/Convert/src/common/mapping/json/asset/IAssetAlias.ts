export interface IAssetAlias
{
    link?: string;
    flipH?: boolean;
    flipV?: boolean;
}
