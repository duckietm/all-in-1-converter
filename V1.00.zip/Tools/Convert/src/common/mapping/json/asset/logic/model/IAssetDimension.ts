export interface IAssetDimension
{
    x: number;
    y: number;
    z?: number;
    centerZ?: number;
}
