export interface ISoundSample
{
    id?: number;
    noPitch?: boolean;
}
