export interface IAssetVisualAnimationSequenceFrameOffset
{
    direction?: number;
    x?: number;
    y?: number;
}
