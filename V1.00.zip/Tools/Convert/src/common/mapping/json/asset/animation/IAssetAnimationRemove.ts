export interface IAssetAnimationRemove
{
    id?: string;
}
