export interface IAsset
{
    source?: string;
    x?: number;
    y?: number;
    flipH?: boolean;
    flipV?: boolean;
    usesPalette?: boolean;
}
