export interface IAssetAnimationAvatar
{
    ink?: number;
    foreground?: string;
    background?: string;
}
