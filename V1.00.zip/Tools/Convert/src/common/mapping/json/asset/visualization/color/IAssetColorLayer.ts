export interface IAssetColorLayer
{
    color?: number;
}
