import { IProductType } from './IProductType';

export interface IProductData
{
    productdata?: {
        product: IProductType[]
    };
}
