export interface IProductType
{
    code: string;
    name: string;
    description: string;
}
