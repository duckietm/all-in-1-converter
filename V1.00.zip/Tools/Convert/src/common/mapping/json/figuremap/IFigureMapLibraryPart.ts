export interface IFigureMapLibraryPart
{
    id?: number;
    type?: string;
}
